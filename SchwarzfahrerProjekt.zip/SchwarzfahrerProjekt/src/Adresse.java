package src;

public class Adresse {
}
