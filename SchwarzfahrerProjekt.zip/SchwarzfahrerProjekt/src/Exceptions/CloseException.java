package src.Exceptions;

public class CloseException extends Exception{

    public CloseException(){
        System.out.println("Something got closed.");
    }
}
