package src.users;

import src.Adresse;

import java.util.Date;

public class Schwarzfahrer extends Person{
    /* Attribute
    String name;
    String vorname;
    String namenszusatz;
    String geschlecht;
    String telefonnummer;
    String email;
     */
    String ausweisnummer;
    String geburtsort;
    Date Geburtsdatum;
    Adresse adresse;
}
